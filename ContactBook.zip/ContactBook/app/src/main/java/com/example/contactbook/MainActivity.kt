
package com.example.contactbook

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.room.*
import androidx.room.withTransaction
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

// 1. Contact Entity
@Entity(tableName = "contacts")
data class Contact(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val name: String,
    val phone: String
)

// 2. Contact DAO
@Dao
interface ContactDao {

    @Insert
    suspend fun insertContact(contact: Contact)

    @Query("SELECT * FROM contacts")
    fun getAllContacts(): Flow<List<Contact>>

    @Query("SELECT COUNT(*) FROM contacts")
    suspend fun getContactCount(): Int
}

// 3. Contact Database
@Database(
    entities = [Contact::class],
    version = 1,
    exportSchema = false
)
abstract class ContactDatabase : RoomDatabase() {

    abstract fun contactDao(): ContactDao

    companion object {

        @Volatile
        private var INSTANCE: ContactDatabase? = null

        fun getDatabase(context: android.content.Context): ContactDatabase {

            return INSTANCE ?: synchronized(this) {

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ContactDatabase::class.java,
                    "contact_database"
                ).build()

                INSTANCE = instance
                instance
            }
        }
    }
}

// 4. Contact ViewModel
class ContactViewModel(application: Application) :
    AndroidViewModel(application) {

    private val database =
        ContactDatabase.getDatabase(application)

    private val dao = database.contactDao()

    val contacts = dao.getAllContacts().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    private val _message = MutableStateFlow("")
    val message = _message.asStateFlow()

    fun addContact(
        name: String,
        phone: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {

            if (name.isBlank() || phone.isBlank()) {
                _message.value = "Please enter all details"
                return@launch
            }

            val inserted = database.withTransaction {

                if (dao.getContactCount() < 3) {

                    dao.insertContact(
                        Contact(
                            name = name.trim(),
                            phone = phone.trim()
                        )
                    )

                    true

                } else {
                    false
                }
            }

            if (inserted) {
                _message.value = "Contact saved successfully"
                onSuccess()
            } else {
                _message.value = "Contact limit reached!"
            }
        }
    }
}

// 5. Main Activity
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                ContactScreen()
            }
        }
    }
}

// 6. Contact Screen UI
@Composable
fun ContactScreen(
    vm: ContactViewModel = viewModel()
) {

    val contacts by vm.contacts.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()

    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp)
    ) {

        Text(
            text = "Contact Book",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Enter Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = phone,
            onValueChange = { phone = it },
            label = { Text("Enter Phone Number") },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone
            ),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                vm.addContact(name, phone) {
                    name = ""
                    phone = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Add Contact")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = message,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Saved Contacts (${contacts.size}/3)",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn {

            items(
                items = contacts,
                key = { it.id }
            ) { contact ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {

                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {

                        Text(
                            text = "Name: ${contact.name}"
                        )

                        Text(
                            text = "Phone: ${contact.phone}"
                        )
                    }
                }
            }
        }
    }
}
